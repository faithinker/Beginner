
import Foundation

// Please enter the file path uploaded to the dropbox here.
// https://dl.dropboxusercontent.com
let bigFileUrlStr = "https://dl.dropboxusercontent.com/s/i1fu5aszcsvhwgj/intro-big.mp4?dl=0"
let smallFileUrlStr = "https://dl.dropboxusercontent.com/s/e6dye4bq28ww1wd/intro-small.mp4?dl=0"
let picUrlStr = "https://dl.dropboxusercontent.com/s/4tb97ydxi8gqmru/pic.jpg?dl=0"

// Please enter the dropbox access token here.
let dropBoxAccessToken = "sl.Atxo8CUfoEI1trzaVoQJ2i24Tx1LHmR-df48p8JAiY_964nPO4rBb4gK72yTCZMvMVTfexb_Ak4GCtYioi9N3HnqdWZ68mgY85C7JW9Lm4sI0tl-XzKglVijJvbrKYIWqqqxJR0"
