
import UIKit


class UploadTaskViewController: UIViewController {
   
   @IBOutlet weak var sizeLabel: UILabel!
   
   @IBOutlet weak var uploadProgressView: UIProgressView!
   
   lazy var formatter: ByteCountFormatter = {
      let f = ByteCountFormatter()
      f.countStyle = .file
      return f
   }()
   
   var dropboxUploadRequest: URLRequest {
      guard let apiUrl = URL(string: "https://content.dropboxapi.com/2/files/upload") else {
         fatalError("Invalid URL")
      }
      
      var request = URLRequest(url: apiUrl)
      request.httpMethod = "POST"
      request.setValue("Bearer \(dropBoxAccessToken)", forHTTPHeaderField: "Authorization")
      request.setValue("{\"path\": \"/intro.mp4\",\"mode\": \"overwrite\",\"autorename\": true,\"mute\": false,\"strict_conflict\": false}", forHTTPHeaderField: "Dropbox-API-Arg")
      request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
      
      return request
   }
   
   // Code Input Point #2
   
   // Code Input Point #2
   
   @IBAction func uploadWithProgress(_ sender: Any) {
      guard let resourceUrl = Bundle.main.url(forResource: "intro", withExtension: "mp4") else {
         fatalError("Invalid Resource")
      }
      
      guard let data = try? Data(contentsOf: resourceUrl) else {
         fatalError("Invalid Data")
      }
      
      uploadProgressView.progress = 0.0
   
      // Code Input Point #3
      
      // Code Input Point #3
   }
   
   @IBAction func upload(_ sender: Any) {
      guard let resourceUrl = Bundle.main.url(forResource: "intro", withExtension: "mp4") else {
         fatalError("Invalid Resource")
      }
      
      guard let data = try? Data(contentsOf: resourceUrl) else {
         fatalError("Invalid Data")
      }
      
      // Code Input Point #1
      
      // Code Input Point #1
   }
   
   override func viewWillDisappear(_ animated: Bool) {
      super.viewWillDisappear(animated)

      // Code Input Point #5
      
      // Code Input Point #5
   }
}

// Code Input Point #4

// Code Input Point #4
